"""SupportSense AI application modules."""
